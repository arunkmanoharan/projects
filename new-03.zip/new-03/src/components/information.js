// basic react component starting template
import React, { Component } from 'react';
import styled, { css } from 'styled-components'

class Information extends Component {
    render() {
		const Label = styled.label`
	        font-weight: 500;
	        font-size: 1.6em;
	        color: #3c3a3a;
	      `;
	     const Info = styled.label`
	            font-weight: 400;
			    line-height: 3;
	      `;
		return (
			<div>
		  <div>
		    	<Label>Get Quote</Label>		    	
		  </div>
		  <div>
		  		<Info>Customize your quote dynamically by changing the coverage % you are preferable with, adding and removing covers you would like to have</Info>
		  </div>
		  </div>
		);
    }
}

export default Information;
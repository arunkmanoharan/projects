// basic react component starting template
import React, { Component } from 'react';
import styled, { css } from 'styled-components'
import Slider from 'rc-slider/lib/Slider';
import 'rc-slider/assets/index.css';

class ProgresBar extends Component {
	constructor(props) {
		super(props)
		const { value } = this.props
		this.state = { value }
	}
	  onSliderChange = (value) => {
	    this.setState({
	      value,
	    });
	  }
	  setValue(e) {
		this.setState({ value: e })
	}
	update() {
		this.props.update(this.state)
	}
    render() {
		const Box = styled.div`
			  padding: 1em 1em 1em;
			  text-align:left;
			`;
		const Label = styled.label`
			  font-weight: 600;
			  text-align:center;
			  text-align:-webkit-center;
			  color: #07556c;
			`;
		return (
		  <div>
		  	<Box>
		  		<label>{this.props.title}</label>
		  		<Slider defaulValue ={Number(this.props.value)} value ={Number(this.state.value)} value={this.state.value} onChange={this.setValue.bind(this)} onAfterChange={this.update.bind(this)}/>
		  		<Label>{this.state.value}%</Label>
		  	</Box>
		  </div>
		);
    }
}

export default ProgresBar;
// basic react component starting template
import React, { Component } from 'react';
import styled, { css } from 'styled-components'

class Txtbox extends Component {
    render() {
		 const Input = styled.input.attrs({
			  type: 'text'
			})`
		 	  padding: 4px 8px 3px;
    		  border-radius: 3px;
              border: 2px solid #cecece;
			  width: 80%;
			  color: #8e8c8c;
			`;
			const Box = styled.div`
			  padding: 1em 1em 1em;
			  text-align:left;
			`;
			const Label = styled.label`
	            font-weight: 400;
			    font-size: 1em;
	      `;
		return (
		  <div className='col-lg-12'>
		    <Box className="row">
		    	<Label>{this.props.title}</Label>
		    	<Input defaultValue={this.props.value}/>
		    </Box>
		    
		  </div>
		);
    }
}

export default Txtbox;
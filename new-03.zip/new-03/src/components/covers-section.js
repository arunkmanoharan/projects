// basic react component starting template
import React, { Component } from 'react';
import styled, { css } from 'styled-components'
import CheckBox from './checkBox.js'
class CoversSection extends Component {
    render() {
    	const itms = this.props.data;
		return (
			<div>
				<div className='row'>
					<div className='col-lg-4 col-md-4'>
						<CheckBox data = {itms[0]}/>
					</div>
					<div className='col-lg-4 col-md-4'>
					<CheckBox data = {itms[1]}/>
					</div>
		  		  </div>
		  		  <div className='row'>
					<div className='col-lg-4 col-md-4'>
						<CheckBox data = {itms[2]}/>
					</div>
					<div className='col-lg-4 col-md-4'>
					<CheckBox data = {itms[3]}/>
					</div>
		  		  </div>
		  		  <div className='row'>
					<div className='col-lg-4 col-md-4'>
						<CheckBox data = {itms[4]}/>
					</div>
					<div className='col-lg-4 col-md-4'>
					<CheckBox data = {itms[5]}/>
					</div>
		  		  </div>
		  		</div>
		);
    }
}

export default CoversSection;
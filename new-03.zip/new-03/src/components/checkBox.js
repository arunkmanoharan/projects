// basic react component starting template
import React, { Component } from 'react';
import styled, { css } from 'styled-components'

class CheckBox extends Component {
    render() {
		 const Input = styled.input.attrs({
			  type: 'checkbox'
			})`
			  background: #cecece;
			  border-radius: 8px;
			  border: 1px solid gray;
			  color: white;
			  height:20px;
			  width:20px;
			  margin-right: 1em;
			  vertical-align: middle;
			    position: relative;
			    bottom: 1px;
			`;
			const Box = styled.div`
			  padding: 0em 0em 1em;
			  text-align:left;
			`;
			const Info = styled.span`
	            font-weight: 400;
			    line-height: 2	;
			    margin-top: -0.5em;
	      	`;
		return (
		  <div className='col-lg-12'>
		    	<Box><Input value={this.props.data}/><Info>{this.props.data}</Info></Box>
		  </div>
		);
    }
}

export default CheckBox;
import React, { Component } from 'react';
import logo from './logo.svg';
import './App.css';

import { connect } from 'react-redux';
import { defaultFunction } from './actions';
import 'bootstrap/dist/css/bootstrap.min.css';
import LoanToProtect from './components/loanToProtect.js'
import CoversSection from './components/covers-section.js'
import Information from './components/information.js'
import styled, { css } from 'styled-components'

class App extends Component {

  componentDidMount() {
    // call default function to display redux operation
    this.props.defaultFunction();
  }

  render() {
    const coversOptions = [
      'Job Loss',
      'Injury/Sickness',
      'Critical Illness',
      'Death',
      'Options'
    ];
    const initialJson = [{
      'title': 'Home Loans',
      'textboxTitle': 'Debt Amount',
      'amount': '$50,000',
      'coverageTitle': '% of Coverage',
      'coverageValue': '25'
    },
    {
      'title': 'Personal Loans',
      'textboxTitle': 'Debt Amount',
      'amount': '$30,000',
      'coverageTitle': '% of Coverage',
      'coverageValue': '55'
    },
    {
      'title': 'Credit Cards',
      'textboxTitle': 'Debt Amount',
      'amount': '$40,000',
      'coverageTitle': '% of Coverage',
      'coverageValue': '75'
    },
    {'totalProtection': '120,000'}
    ];



    const Container = styled.div`
        margin: 1em 1em 2em;
        text-align:left;
        margin:auto;
        width:95%
        background: #FFF;
        height:100%;
      `;
    const BoxQuote = styled.div`
        text-align:left;
        background: #07556c;
        border-radius: 10px;
        color: white;
        height:100%;
      `;
    const Label = styled.label`
        font-weight: 600;
        text-align:center;
        text-align:-webkit-center;
        font-size: 1.2em;
        line-height: 2;
        color: #545454;
      `;
      const Box = styled.div`
        padding: 1em 1em 1em;
        text-align:left;
        -webkit-box-shadow: 0px 4px 20px 0px rgba(168,166,168,1);
        -moz-box-shadow: 0px 4px 20px 0px rgba(168,166,168,1);
        box-shadow: 0px 4px 20px 0px rgba(168,166,168,1);
      `;
      const LabelTotal = styled.label`
          font-weight: 500;
          font-size: 1.9em;
          color: #3c3a3a;
        `;
    return (
      <Container>
        <Information/>
      <Box>

        <div className="row">
          <div className='col-lg-9 col-md-9'>
            <div className="row">
                <div className='col-lg-4 col-md-4 col-sm-4 col-xs-12'>
                  <Label>Loans To Protect</Label>
                </div>
                <div className='col-lg-4 col-md-4 col-sm-4 col-xs-12'>
                </div>
                <div className='col-lg-4 col-md-4 col-sm-4 col-xs-12'>
                  <Label>Total Protection:</Label> $ <LabelTotal>{initialJson[3].totalProtection}</LabelTotal>
                </div>
              </div>
          <div className="row">
            <div className="col-lg-12 col-md-12">
              <LoanToProtect data={initialJson}/>
            </div>
          </div>
          <hr />
          <div>
            <Label>What covers would you like</Label>
          </div>
          <div className="row">
            <div className="col-lg-12 col-md-12">
              <CoversSection data={coversOptions}/>
            </div>
          </div>
        </div>
        <div className='col-lg-3 col-md-3'>
          <BoxQuote>
          Test
          </BoxQuote>
        </div>
       </div>
      </Box>
      </Container>
    )
  }
}

// function to convert the global state obtained from redux to local props
function mapStateToProps(state) {
  return {
    default: state.default
  };
}

export default connect(mapStateToProps, { defaultFunction })(App);

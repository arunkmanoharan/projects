import React from "react";
import { render } from "react-dom";
import { connect } from 'react-redux';
import { defaultFunction } from '../actions';
import ReactTable from "react-table";
import "react-table/react-table.css";
import FontAwesome from 'react-fontawesome';
import fontawesome from '@fortawesome/fontawesome'
import FontAwesomeIcon from 'react-fontawesome';
import { faHome, faCoffee } from '@fortawesome/fontawesome-free-solid';

class TableComponent extends React.Component {
  constructor() {
    super();
    this.state = {
      data: [{
        "addressType":'',
        "streetAddress":'',
        "city":'',
        "state":'',
        "postalCode":'',
        "action":'',
      }]
    };
    this.renderEditable = this.renderEditable.bind(this);
  }

  componentDidMount() {
    // call default function to display redux operation
    this.props.defaultFunction();
  }

  renderEditable(cellInfo) {
    return (
      <div
        style={{ backgroundColor: "white", height:"35px" }}
        contentEditable
        suppressContentEditableWarning
        onBlur={e => {
           const data = [...this.state.data];
           data[cellInfo.index][cellInfo.column.id] = e.target.innerHTML;
           this.setState({ data });
         }}

      />
    );
  }
  render() {
    const cols = this.props.columns[0].columns.map(obj=>{
      if(obj['Cell'] == undefined){
        obj['Cell'] = this.renderEditable;
      }
      return obj;
    })
    const { data } = this.state;
    return (
      <div className="reactTableContainr">
        <h5>{this.props.title} <div className="plusIcon"><FontAwesomeIcon name={'plus-circle'}/></div></h5><hr/>
        <ReactTable
          data={data}
          columns={this.props.columns}
          defaultPageSize={this.props.defaultPageSize}
          className={this.props.className}
          minRows={this.props.minRows}
        />
        <br />
      </div>
    );
  }
}

function mapStateToProps(state) {
  return {
    default: state.default
  };
}

export default connect(mapStateToProps, { defaultFunction })(TableComponent);

// basic react component starting template
import React, { Component } from 'react';
import CheckBox from './checkBox.js'
import { connect } from 'react-redux';
import { defaultFunction } from '../actions';
import TableComponent from "./tableComponent.js";
import FontAwesome from 'react-fontawesome';
import fontawesome from '@fortawesome/fontawesome'
import FontAwesomeIcon from 'react-fontawesome';
import { faHome, faCoffee } from '@fortawesome/fontawesome-free-solid';

class PolicyTabContent2 extends Component {
  componentDidMount() {
    // call default function to display redux operation
    this.props.defaultFunction();
  }

    render() {

      const addressDetails  = [
            {
              columns: [
                {
                  Header: "Address Type",
                  accessor: "addressType",
                  Cell: () => (
                    <div  className="trashIcon"><select className="form-control">
                      <option selected value="Present">Present</option>
                      <option value="Permanent">Permanent</option>
                    </select></div>
                  )
                },
                {

                  Header: "Street Address",
                  accessor: "streetAddress"
                },
                {
                  Header: "City",
                  accessor: "city"
                },
                {
                  Header: "State",
                  accessor: "state"
                },
                {
                  Header: "PostalCode",
                  accessor: "postalCode"
                },
                {
                  Header: "Action",
                  accessor: "action",
                  Cell: () => (
                    <div  className="trashIcon"><FontAwesomeIcon name={'trash'}/></div>
                  )
                }

              ]
            },

          ];

		return (
		  <div className="row policyContent">
        <div className="col-lg-12  col-md-12 col-sm-12  col-xs-12 ">
          <h4>{`Enter your Emergency Contact Details`}</h4><hr/>
            <h5>Insured Details</h5>
                  <form>
                    <div className="row">
                      <div className="form-group col-lg-4  col-md-4 col-sm-12  col-xs-12">
                          <label htmlFor="">First Name </label>
                          <input type="text" className="form-control" />
                        </div>
                        <div className="form-group col-lg-4  col-md-4 col-sm-12  col-xs-12">
                          <label htmlFor="">Last Name </label>
                          <input type="text" className="form-control" />
                        </div>
                        <div className="form-group col-lg-4  col-md-4 col-sm-12  col-xs-12">
                          <label htmlFor="">Middle Name </label>
                          <input type="text" className="form-control" />
                        </div>
                      </div>
                      <div className="row">
                          <div className="form-group col-lg-4  col-md-4 col-sm-12  col-xs-12">
                            <label htmlFor="">{`Date of Birth `}</label>
                            <input type="date" className="form-control" />
                          </div>
                          <div className="form-group col-lg-4  col-md-4 col-sm-12  col-xs-12">
                            <label htmlFor="">Gender </label>
                            <select className="form-control">
                              <option selected value="Male">Male</option>
                              <option value="Female">Female</option>
                              <option  value="Other">Other</option>
                            </select>
                          </div>
                          <div className="form-group col-lg-4  col-md-4 col-sm-12  col-xs-12">
                            <label htmlFor="">Occupation Status</label>
                            <select className="form-control">
                              <option selected value="Fulltime">Working- Fulltime</option>
                              <option value="Part time">Working- Part time</option>
                              <option  value="Home">Working from Home</option>
                            </select>
                          </div>
                        </div>
                        <div className="row">
                            <div className="form-group col-lg-4  col-md-4 col-sm-12  col-xs-12">
                              <label htmlFor="">Phone </label>
                              <input type="number" className="form-control" />
                            </div>
                            <div className="form-group col-lg-4  col-md-4 col-sm-12  col-xs-12">
                              <label htmlFor="">Email </label>
                              <input type="email" className="form-control" />
                            </div>

                          </div>

                  </form>

                  <TableComponent title={'Address'} columns = {addressDetails}  defaultPageSize={1}  className="-striped -highlight" showPagination={false} minRows= {2}/>

                  </div>
            </div>
		);
    }
}

function mapStateToProps(state) {
  return {
    default: state.default
  };
}

export default connect(mapStateToProps, { defaultFunction })(PolicyTabContent2);

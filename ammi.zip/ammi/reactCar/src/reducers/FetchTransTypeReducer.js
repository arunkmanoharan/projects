import {
    FETCH_TRANSTYPE_PENDING,
    FETCH_TRANSTYPE_FULFILLED,
    FETCH_TRANSTYPE_REJECTED
} from '../actions';


// INITIALIZE STATE

const initialState = {
    transType: [],
    fetching: false,
    fetched: false,
    failed: false
};


// REDUCER

export const FetchTransTypeReducer = (state = initialState, action) => {
    switch(action.type) {
        case FETCH_TRANSTYPE_PENDING:
            return {
                ...state,
                transType: [],
                fetching: true,
                fetched: false,
                failed: false
            };
        case FETCH_TRANSTYPE_FULFILLED:
            return {
                ...state,
                transType: action.payload,
                fetching: false,
                fetched: true,
                failed: false
            };
        case FETCH_TRANSTYPE_REJECTED:
            return {
                ...state,
                transType: [],
                fetching: false,
                fetched: false,
                failed: true
            };
        default:
            return state;
    }
};
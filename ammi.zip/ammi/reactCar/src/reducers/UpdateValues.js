import {
    UPDATE_VALUE
} from '../actions';


// INITIALIZE STATE

const initialState = {
    values: {}
};


// REDUCER

export const UpdateValues = (state = initialState, action) => {
    switch(action.type) {
        case UPDATE_VALUE:
            return {
                ...state,
                values: Object.assign({}, state.values, action.payload)
            };
        default:
            return state;
    }
};
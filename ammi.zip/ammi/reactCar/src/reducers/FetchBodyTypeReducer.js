import {
    FETCH_BODYTYPE_PENDING,
    FETCH_BODYTYPE_FULFILLED,
    FETCH_BODYTYPE_REJECTED
} from '../actions';


// INITIALIZE STATE

const initialState = {
    bodyType: [],
    fetching: false,
    fetched: false,
    failed: false
};


// REDUCER

export const FetchBodyTypeReducer = (state = initialState, action) => {
    switch(action.type) {
        case FETCH_BODYTYPE_PENDING:
            return {
                ...state,
                bodyType: [],
                fetching: true,
                fetched: false,
                failed: false
            };
        case FETCH_BODYTYPE_FULFILLED:
            return {
                ...state,
                bodyType: action.payload,
                fetching: false,
                fetched: true,
                failed: false
            };
        case FETCH_BODYTYPE_REJECTED:
            return {
                ...state,
                bodyType: [],
                fetching: false,
                fetched: false,
                failed: true
            };
        default:
            return state;
    }
};
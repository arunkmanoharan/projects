// IMPORT PACKAGE REFERENCES

import { combineReducers } from 'redux';


// IMPORT REDUCERS


import { FetchBodyTypeReducer } from '../reducers/FetchBodyTypeReducer';
import { FetchCylindersReducer } from '../reducers/FetchCylindersReducer';
import { FetchMakeReducer } from '../reducers/FetchMakeReducer';
import { FetchModelReducer } from '../reducers/FetchModelReducer';
import { FetchStatesReducer } from '../reducers/FetchStatesReducer';
import { FetchTransTypeReducer } from '../reducers/FetchTransTypeReducer';
import { FetchYearReducer } from '../reducers/FetchYearReducer';
import { UpdateValues } from '../reducers/UpdateValues';


// EXPORT APP REDUCER

export default combineReducers({
    bodyType: FetchBodyTypeReducer,
    cylinders: FetchCylindersReducer,
    make: FetchMakeReducer,
    model: FetchModelReducer,
    states: FetchStatesReducer,
    transType: FetchTransTypeReducer,
    year: FetchYearReducer,
    values: UpdateValues
});
import {
    FETCH_YEAR_PENDING,
    FETCH_YEAR_FULFILLED,
    FETCH_YEAR_REJECTED
} from '../actions';


// INITIALIZE STATE

const initialState = {
    year: [],
    fetching: false,
    fetched: false,
    failed: false
};


// REDUCER

export const FetchYearReducer = (state = initialState, action) => {
    switch(action.type) {
        case FETCH_YEAR_PENDING:
            return {
                ...state,
                year: [],
                fetching: true,
                fetched: false,
                failed: false
            };
        case FETCH_YEAR_FULFILLED:
            return {
                ...state,
                year: action.payload,
                fetching: false,
                fetched: true,
                failed: false
            };
        case FETCH_YEAR_REJECTED:
            return {
                ...state,
                year: [],
                fetching: false,
                fetched: false,
                failed: true
            };
        default:
            return state;
    }
};
import {
    FETCH_STATES_PENDING,
    FETCH_STATES_FULFILLED,
    FETCH_STATES_REJECTED
} from '../actions';


// INITIALIZE STATE

const initialState = {
    states: [],
    fetching: false,
    fetched: false,
    failed: false
};


// REDUCER

export const FetchStatesReducer = (state = initialState, action) => {
    switch(action.type) {
        case FETCH_STATES_PENDING:
            return {
                ...state,
                states: [],
                fetching: true,
                fetched: false,
                failed: false
            };
        case FETCH_STATES_FULFILLED:
            return {
                ...state,
                states: action.payload,
                fetching: false,
                fetched: true,
                failed: false
            };
        case FETCH_STATES_REJECTED:
            return {
                ...state,
                states: [],
                fetching: false,
                fetched: false,
                failed: true
            };
        default:
            return state;
    }
};
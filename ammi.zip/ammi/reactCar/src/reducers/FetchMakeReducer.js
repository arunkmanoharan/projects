import {
    FETCH_MAKE_PENDING,
    FETCH_MAKE_FULFILLED,
    FETCH_MAKE_REJECTED
} from '../actions';


// INITIALIZE STATE

const initialState = {
    make: [],
    fetching: false,
    fetched: false,
    failed: false
};


// REDUCER

export const FetchMakeReducer = (state = initialState, action) => {
    switch(action.type) {
        case FETCH_MAKE_PENDING:
            return {
                ...state,
                make: [],
                fetching: true,
                fetched: false,
                failed: false
            };
        case FETCH_MAKE_FULFILLED:
            return {
                ...state,
                make: action.payload,
                fetching: false,
                fetched: true,
                failed: false
            };
        case FETCH_MAKE_REJECTED:
            return {
                ...state,
                make: [],
                fetching: false,
                fetched: false,
                failed: true
            };
        default:
            return state;
    }
};
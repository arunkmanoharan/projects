import {
    FETCH_MODEL_PENDING,
    FETCH_MODEL_FULFILLED,
    FETCH_MODEL_REJECTED
} from '../actions';


// INITIALIZE STATE

const initialState = {
    model: [],
    fetching: false,
    fetched: false,
    failed: false
};


// REDUCER

export const FetchModelReducer = (state = initialState, action) => {
    switch(action.type) {
        case FETCH_MODEL_PENDING:
            return {
                ...state,
                model: [],
                fetching: true,
                fetched: false,
                failed: false
            };
        case FETCH_MODEL_FULFILLED:
            return {
                ...state,
                model: action.payload,
                fetching: false,
                fetched: true,
                failed: false
            };
        case FETCH_MODEL_REJECTED:
            return {
                ...state,
                model: [],
                fetching: false,
                fetched: false,
                failed: true
            };
        default:
            return state;
    }
};
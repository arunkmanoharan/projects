import {
    FETCH_CYLINDERS_PENDING,
    FETCH_CYLINDERS_FULFILLED,
    FETCH_CYLINDERS_REJECTED
} from '../actions';


// INITIALIZE STATE

const initialState = {
    cylinders: [],
    fetching: false,
    fetched: false,
    failed: false
};


// REDUCER

export const FetchCylindersReducer = (state = initialState, action) => {
    switch(action.type) {
        case FETCH_CYLINDERS_PENDING:
            return {
                ...state,
                cylinders: [],
                fetching: true,
                fetched: false,
                failed: false
            };
        case FETCH_CYLINDERS_FULFILLED:
            return {
                ...state,
                cylinders: action.payload,
                fetching: false,
                fetched: true,
                failed: false
            };
        case FETCH_CYLINDERS_REJECTED:
            return {
                ...state,
                cylinders: [],
                fetching: false,
                fetched: false,
                failed: true
            };
        default:
            return state;
    }
};
import React, { Component } from 'react';
import './App.css';

import { connect } from 'react-redux';
import 'bootstrap/dist/css/bootstrap.min.css';
import Home from './components/home';

class App extends Component {
 render() {

    return (
      <Home store={this.props.store}></Home>
    )
  }
}

function mapStateToProps(state) {
  return {
    default: state.default
  };
}

export default connect(mapStateToProps)(App);

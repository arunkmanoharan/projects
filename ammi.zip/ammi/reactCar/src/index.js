import React from 'react'
import { render } from 'react-dom'
import { Provider } from 'react-redux'
import { createStore } from 'redux'
import rootReducer from './reducers/index.js'
import App from './App.js'

const store = createStore(rootReducer)
console.log(store.getState())
render(
  <Provider store={store}>
    <App store={store}/>
  </Provider>,
  document.getElementById('root')
  )
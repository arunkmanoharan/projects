// basic react component starting template
import React, { Component } from 'react';

class SelectBox extends Component {
    getOptionsList() {
      let options = []
      if(this.props.options) {
        Object.keys(this.props.options).forEach(item => {
          options.push(<option value={this.props.options[item].id}> {this.props.options[item][this.props.id]} </option>)
        })
      }
      return options
    }
    render() {
    	const options = this.getOptionsList()
		return (
		  <div className='col-lg-6 col-md-6'>
              <select className={this.props.className} id={this.props.id} onChange={this.props.onChange}>
                  <option>Select </option>
                  {options}
              </select>
            </div>
		);
    }
}

export default SelectBox;

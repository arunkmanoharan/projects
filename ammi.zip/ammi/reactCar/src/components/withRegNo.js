// basic react component starting template
import React, { Component } from 'react';
import { connect } from 'react-redux';
import {fetchStatesAction, updateValue} from '../actions'
import SelectBox from './SelectBox'

class WithRegNo extends Component {
  constructor(props) {
    super(props)
    this.state = {
      withReg: true,
      reg_no: '',
      state: '',
      errors: {
        reg_no: false,
        state: false
      }
    }
    this.onSubmit = this.onSubmit.bind(this)
    this.onChange = this.onChange.bind(this)
  }
	componentDidMount() {
    console.log(this.props)
		this.props.store.dispatch(fetchStatesAction())
	}
  onSubmit(event) {
    const errdata = { reg_no: this.state.reg_no === '', state: this.state.state === '' }
    this.setState({errors: errdata})
  }
  onChange(event) {
    this.setState({[event.target.id]: event.target.value})
    this.props.store.dispatch(updateValue({[event.target.id]: event.target.value}))
  }
    render() {
		const regErr = this.state.errors.reg_no ? 'has-error' : ''
    const stateErr = this.state.errors.state ? 'has-error' : ''
		return (
		  <div className="row">
              <div className="col-lg-1"></div>
              <div className="col-lg-4">
                  <h3>Find your Car</h3>
                  <form>
                        <div className={`form-group ${regErr}`} >
                        <label for="reg_no">Registration Number:</label>
                        <input type="text" className={`form-control ${regErr}`} id="reg_no" onChange={this.onChange}/>
                      </div>
                      <div className="form-group">
                          <button type="button" className="btn btn-link" onClick={this.props.onChange}>I don't know or have a registration number</button>
                      </div>
                      <div className={`form-group ${stateErr}`}>
                        <label for="pwd">State the car registered in:</label>
                    <br />    
                          <SelectBox className={`form-control ${stateErr}`} id="state" onChange={this.onChange} options={this.props.states} />
                          
                      </div>
                      <div className="form-group">
                          <button type="button" className="btn" onClick={this.onSubmit}>Find Your Car</button>
                      </div>
                  </form>
               </div>
            </div>
		);
    }
}

function mapStateToProps(state) {
  return {
    states: state.states.states
  };
}

export default connect(mapStateToProps)(WithRegNo);
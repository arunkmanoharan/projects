// basic react component starting template
import React, { Component } from 'react';
import { connect } from 'react-redux';
import {updateValue} from '../actions'
import SelectBox from './SelectBox'

class WithVehicleDetails extends Component {
  constructor(props) {
    super(props)
    this.state = {
      year: '',
      make: '',
      model: '',
      transtype: '',
      bodyType: '',
      cylinders: '',
      errors: {
        year: false,
        make: false,
        model: false,
        transtype: false,
        bodyType: false,
        cylinders: false,
      }
    }
    this.onSubmit = this.onSubmit.bind(this)
    this.onChange = this.onChange.bind(this)
  }
  onSubmit(event) {
    const errdata = { year: this.state.year === '',
        make: this.state.make === '',
        model: this.state.model === '',
        transtype: this.state.transtype === '',
        bodyType: this.state.bodyType === '',
        cylinders: this.state.cylinders === '', }
    this.setState({errors: errdata})
  }
  onChange(event) {
    this.setState({[event.target.id]: event.target.value})
    this.props.store.dispatch(updateValue({[event.target.id]: event.target.value}))
  }
    render() {
  		  const year = this.state.errors.year  ? 'has-error' : ''
        const make = this.state.errors.make  ? 'has-error' : ''
        const model = this.state.errors.model  ? 'has-error' : ''
        const transtype = this.state.errors.transtype  ? 'has-error' : ''
        const bodyType = this.state.errors.bodyType  ? 'has-error' : ''
        const cylinders = this.state.errors.cylinders  ? 'has-error' : ''


		return (
		  <div className="row">
                <div className="col-lg-1"></div>
                  <div className="col-lg-6 col-lg-offset-3  col-md-8 col-md-offset-2  col-sm-12  col-xs-12 ">
                      <h3>That's OK, let's find your car another way...</h3>
                                              
                      <div className={`row ${year}`}>
                        <div className='col-lg-4 col-md-4'>
                          <label for="pwd">Year of manufacture</label>
                        </div>
                        <div className='col-lg-6 col-md-6'>
                          <SelectBox className={`form-control ${year}`} onChange={this.onChange} id="year" options={this.props.year} />
                        </div>
                      </div>
                      <br />
                      <div className={`row ${make}`}>
                        <div className='col-lg-4 col-md-4'>
                          <label for="pwd">Car make</label>
                        </div>
                        <div className='col-lg-6 col-md-6'>
                          <SelectBox className={`form-control ${make}`} onChange={this.onChange} id="make" options={this.props.make} />
                        </div>
                      </div>
                      <br />
                      <div className={`row ${model}`}>
                        <div className='col-lg-4 col-md-4'>
                          <label for="pwd">Car model</label>
                        </div>
                        <div className='col-lg-6 col-md-6'>
                            <SelectBox className={`form-control ${make}`} onChange={this.onChange} id="model" options={this.props.model} />
                        </div>
                      </div>
                      <br />
                      <div className={`row ${transtype}`}>
                        <div className='col-lg-4 col-md-4'>
                          <label for="pwd">Transmission type</label>
                        </div>
                        <div className='col-lg-6 col-md-6'>
                        <SelectBox className={`form-control ${make}`} onChange={this.onChange} id="transType" options={this.props.transType} />
                        </div>
                      </div>
                      <br />
                      <div className={`row ${cylinders}`}>
                        <div className='col-lg-4 col-md-4'>
                          <label for="pwd">Number of cylinders</label>
                        </div>
                        <div className='col-lg-6 col-md-6'>
                        <SelectBox className={`form-control ${make}`} onChange={this.onChange} id="cylinders" options={this.props.cylinders} />
                        </div>
                      </div>
                      <br />
                      <div className={`row ${bodyType}`}>
                        <div className='col-lg-4 col-md-4'>
                          <label for="pwd">Body type</label>
                        </div>
                        <div className='col-lg-6 col-md-6'>
                        <SelectBox className={`form-control ${make}`} onChange={this.onChange} id="bodyType" options={this.props.bodyType} />
                        </div>
                      </div>
                      <br />
                    <div className="form-group">
                    <button type="button" onClick={this.props.onChange} className="btn btn-link">Or find my car using registration</button>
                    </div>
                    <div className="form-group">
                          <button type="button" className="btn" onClick={this.onSubmit}>Find Your Car</button>
                      </div>
               </div>
            </div>
		);
    }
}

function mapStateToProps(state) {
  return {
    year: state.year.year,
    make: state.make.make,
    model: state.model.model,
    transtype: state.transType.transType,
    bodyType: state.bodyType.bodyType,
    cylinders: state.cylinders.cylinders,
  };
}

export default connect(mapStateToProps)(WithVehicleDetails);
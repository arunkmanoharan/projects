import React, { Component } from 'react';
import { connect } from 'react-redux';
import WithRegNo from './withRegNo.js';
import WithVehicleDetails from './withVehicleDetails.js';

class Home extends Component {
  constructor(props) {
    super(props)
    this.state = {
      withReg: true
    }
    this.onChange = this.onChange.bind(this)
  }
  onChange() {
    this.setState({withReg: !this.state.withReg})
  }
  render() {

    return (<div>
          {this.state.withReg ? <WithRegNo store={this.props.store} onChange={this.onChange}/> : <WithVehicleDetails store={this.props.store} onChange={this.onChange}/>}          
           
    </div>
    )
  }
}

function mapStateToProps(state) {
  return {
    default: state.default
  };
}

export default connect(mapStateToProps)(Home);

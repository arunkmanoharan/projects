// COMPONENT
import axios from 'axios'

export const fetchBodyType = () => {
    return axios.get('/springrest/bodytypes') // JSON File Path
       .then( response => {
         return response.data
     })
     .catch(function (error) {
       console.log(error);
     });
};

export const fetchCylinders = () => {
    axios.get('http://localhost:8080/springrest/bodytypes') // JSON File Path
       .then( response => {
         return response.data
     })
     .catch(function (error) {
       console.log(error);
     });
};

export const fetchMake = () => {
    axios.get('http://localhost:8080/springrest/makes') // JSON File Path
       .then( response => {
         return response.data
     })
     .catch(function (error) {
       console.log(error);
     });
};

export const fetchModel = () => {
    axios.get('http://localhost:8080/springrest/models') // JSON File Path
       .then( response => {
         return response.data
     })
     .catch(function (error) {
       console.log(error);
     });
};

export const fetchStates = () => {
      return [{"id":1,"state":"State1"},{"id":2,"state":"State2"},{"id":3,"state":"State3"},{"id":4,"state":"State4"}]
      /*
    axios.get('http://localhost:8080/springrest/states') // JSON File Path
       .then( response => {
         return response.data
     })
     .catch(function (error) {
       console.log(error);
     });*/
};

export const fetchTransType = () => {
    axios.get('http://localhost:8080/springrest/transTypes') // JSON File Path
       .then( response => {
         return response.data
     })
     .catch(function (error) {
       console.log(error);
     });
};

export const fetchYears = () => {
    axios.get('http://localhost:8080/springrest/years') // JSON File Path
       .then( response => {
         return response.data
     })
     .catch(function (error) {
       console.log(error);
     });
};

import { fetchBodyType, fetchYears, fetchTransType, fetchStates, fetchModel, fetchMake, fetchCylinders } from '../services/index';

// FETCH ACTION NAMES

export const FETCH_BODYTYPE = 'FETCH_BODYTYPE';
export const FETCH_BODYTYPE_PENDING = 'FETCH_BODYTYPE_PENDING';
export const FETCH_BODYTYPE_FULFILLED = 'FETCH_BODYTYPE_FULFILLED';
export const FETCH_BODYTYPE_REJECTED = 'FETCH_BODYTYPE_REJECTED';
export const FETCH_CYLINDERS = 'FETCH_CYLINDER';
export const FETCH_CYLINDERS_PENDING = 'FETCH_CYLINDERS_PENDING';
export const FETCH_CYLINDERS_FULFILLED = 'FETCH_CYLINDERs_FULFILLED';
export const FETCH_CYLINDERS_REJECTED = 'FETCH_CYLINDERS_REJECTED';
export const FETCH_MAKE = 'FETCH_MAKE';
export const FETCH_MAKE_PENDING = 'FETCH_MAKE_PENDING';
export const FETCH_MAKE_FULFILLED = 'FETCH_MAKE_FULFILLED';
export const FETCH_MAKE_REJECTED = 'FETCH_MAKE_REJECTED';
export const FETCH_MODEL = 'FETCH_MODEL';
export const FETCH_MODEL_PENDING = 'FETCH_MODEL_PENDING';
export const FETCH_MODEL_FULFILLED = 'FETCH_MODEL_FULFILLED';
export const FETCH_MODEL_REJECTED = 'FETCH_MODEL_REJECTED';
export const FETCH_STATES = 'FETCH_STATES';
export const FETCH_STATES_PENDING = 'FETCH_STATES_PENDING';
export const FETCH_STATES_FULFILLED = 'FETCH_STATES_FULFILLED';
export const FETCH_STATES_REJECTED = 'FETCH_STATES_REJECTED';
export const FETCH_TRANSTYPE = 'FETCH_TRANSTYPE';
export const FETCH_TRANSTYPE_PENDING = 'FETCH_TRANSTYPE_PENDING';
export const FETCH_TRANSTYPE_FULFILLED = 'FETCH_TRANSTYPE_FULFILLED';
export const FETCH_TRANSTYPE_REJECTED = 'FETCH_TRANSTYPE_REJECTED';
export const FETCH_YEAR = 'FETCH_YEAR';
export const FETCH_YEAR_PENDING = 'FETCH_YEAR_PENDING';
export const FETCH_YEAR_FULFILLED = 'FETCH_YEAR_FULFILLED';
export const FETCH_YEAR_REJECTED = 'FETCH_YEAR_REJECTED';
export const UPDATE_VALUE = 'UPDATE_VALUE';


// ACTION GENERATORS

export const fetchStatesAction = () => ({
	type: FETCH_STATES_FULFILLED,
	payload: fetchStates()
})

export const fetchBodyTypeAction = () => ({
	type: FETCH_BODYTYPE_FULFILLED,
	payload: fetchBodyType()
})

export const fetchCylindersAction = () => ({
	type: FETCH_CYLINDERS_FULFILLED,
	payload: fetchCylinders()
})

export const fetchMakeAction = () => ({
	type: FETCH_MAKE_FULFILLED,
	payload: fetchMake()
})

export const fetchModelAction = () => ({
	type: FETCH_MODEL_FULFILLED,
	payload: fetchModel()
})

export const fetchTransTypeAction = () => ({
	type: FETCH_TRANSTYPE_FULFILLED,
	payload: fetchTransType()
})

export const fetchYearAction = () => ({
	type: FETCH_YEAR_FULFILLED,
	payload: fetchYears()
})

export const updateValue = (value) => ({
	type: UPDATE_VALUE,
	payload: value
})
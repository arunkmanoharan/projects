package com.findyourcar.spring.dao;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import com.findyourcar.spring.model.BodyType;

@Component
public class BodyTypeDAO {

	// Dummy database. Initialize with some dummy values.
	private static List<BodyType> bodyTypes;
	{
		bodyTypes = new ArrayList();
		bodyTypes.add(new BodyType(1, "BodyType1"));
		bodyTypes.add(new BodyType(2, "BodyType1"));
		bodyTypes.add(new BodyType(3, "BodyType1"));
		bodyTypes.add(new BodyType(4, "BodyType1"));
	}

	/**
	 * Returns list of bodyTypes from dummy database.
	 * 
	 * @return list of bodyTypes
	 */
	public List list() {
		return bodyTypes;
	}

	/**
	 * Return bodyType object for given id from dummy database. If bodyType is
	 * not found for id, returns null.
	 * 
	 * @param id
	 *            bodyType id
	 * @return bodyType object for given id
	 */
	public BodyType get(Long id) {

		for (BodyType c : bodyTypes) {
			if (c.getId().equals(id)) {
				return c;
			}
		}
		return null;
	}

	/**
	 * Create new bodyType in dummy database. Updates the id and insert new
	 * bodyType in list.
	 * 
	 * @param bodyType
	 *            BodyType object
	 * @return bodyType object with updated id
	 */
	public BodyType create(BodyType bodyType) {
		bodyType.setId(System.currentTimeMillis());
		bodyTypes.add(bodyType);
		return bodyType;
	}

	/**
	 * Delete the bodyType object from dummy database. If bodyType not found for
	 * given id, returns null.
	 * 
	 * @param id
	 *            the bodyType id
	 * @return id of deleted bodyType object
	 */
	public Long delete(Long id) {

		for (BodyType c : bodyTypes) {
			if (c.getId().equals(id)) {
				bodyTypes.remove(c);
				return id;
			}
		}

		return null;
	}

	/**
	 * Update the bodyType object for given id in dummy database. If bodyType
	 * not exists, returns null
	 * 
	 * @param id
	 * @param bodyType
	 * @return bodyType object with id
	 */
	public BodyType update(Long id, BodyType bodyType) {

		for (BodyType c : bodyTypes) {
			if (c.getId().equals(id)) {
				bodyType.setId(c.getId());
				bodyTypes.remove(c);
				bodyTypes.add(bodyType);
				return bodyType;
			}
		}

		return null;
	}

}
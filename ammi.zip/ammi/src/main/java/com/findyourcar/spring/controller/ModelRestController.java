package com.findyourcar.spring.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.findyourcar.spring.dao.ModelDAO;
import com.findyourcar.spring.model.Model;

@RestController
public class ModelRestController {

	
	@Autowired
	private ModelDAO modelDAO;

	
	@GetMapping("/models")
	public List getModels() {
		return modelDAO.list();
	}

	@GetMapping("/models/{id}")
	public ResponseEntity getModel(@PathVariable("id") Long id) {

		Model model = modelDAO.get(id);
		if (model == null) {
			return new ResponseEntity("No Model found for ID " + id, HttpStatus.NOT_FOUND);
		}

		return new ResponseEntity(model, HttpStatus.OK);
	}

	@PostMapping(value = "/models")
	public ResponseEntity createModel(@RequestBody Model model) {

		modelDAO.create(model);

		return new ResponseEntity(model, HttpStatus.OK);
	}

	@DeleteMapping("/models/{id}")
	public ResponseEntity deleteModel(@PathVariable Long id) {

		if (null == modelDAO.delete(id)) {
			return new ResponseEntity("No Model found for ID " + id, HttpStatus.NOT_FOUND);
		}

		return new ResponseEntity(id, HttpStatus.OK);

	}

	@PutMapping("/models/{id}")
	public ResponseEntity updateModel(@PathVariable Long id, @RequestBody Model model) {

		model = modelDAO.update(id, model);

		if (null == model) {
			return new ResponseEntity("No Model found for ID " + id, HttpStatus.NOT_FOUND);
		}

		return new ResponseEntity(model, HttpStatus.OK);
	}

}
package com.findyourcar.spring.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.findyourcar.spring.dao.TransTypeDAO;
import com.findyourcar.spring.model.TransType;

@RestController
public class TransTypeRestController {

	
	@Autowired
	private TransTypeDAO transTypeDAO;

	
	@GetMapping("/transTypes")
	public List getTransTypes() {
		return transTypeDAO.list();
	}

	@GetMapping("/transTypes/{id}")
	public ResponseEntity getTransType(@PathVariable("id") Long id) {

		TransType transType = transTypeDAO.get(id);
		if (transType == null) {
			return new ResponseEntity("No TransType found for ID " + id, HttpStatus.NOT_FOUND);
		}

		return new ResponseEntity(transType, HttpStatus.OK);
	}

	@PostMapping(value = "/transTypes")
	public ResponseEntity createTransType(@RequestBody TransType transType) {

		transTypeDAO.create(transType);

		return new ResponseEntity(transType, HttpStatus.OK);
	}

	@DeleteMapping("/transTypes/{id}")
	public ResponseEntity deleteTransType(@PathVariable Long id) {

		if (null == transTypeDAO.delete(id)) {
			return new ResponseEntity("No TransType found for ID " + id, HttpStatus.NOT_FOUND);
		}

		return new ResponseEntity(id, HttpStatus.OK);

	}

	@PutMapping("/transTypes/{id}")
	public ResponseEntity updateTransType(@PathVariable Long id, @RequestBody TransType transType) {

		transType = transTypeDAO.update(id, transType);

		if (null == transType) {
			return new ResponseEntity("No TransType found for ID " + id, HttpStatus.NOT_FOUND);
		}

		return new ResponseEntity(transType, HttpStatus.OK);
	}

}
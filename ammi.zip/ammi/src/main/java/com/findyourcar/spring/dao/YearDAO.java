package com.findyourcar.spring.dao;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import com.findyourcar.spring.model.Year;

@Component
public class YearDAO {

	// Dummy database. Initialize with some dummy values.
	private static List<Year> years;
	{
		years = new ArrayList();
		years.add(new Year(1, "Year1"));
		years.add(new Year(2, "Year2"));
		years.add(new Year(3, "Year3"));
		years.add(new Year(4, "Year4"));
	}

	/**
	 * Returns list of years from dummy database.
	 * 
	 * @return list of years
	 */
	public List list() {
		return years;
	}

	/**
	 * Return year object for given id from dummy database. If year is
	 * not found for id, returns null.
	 * 
	 * @param id
	 *            year id
	 * @return year object for given id
	 */
	public Year get(Long id) {

		for (Year c : years) {
			if (c.getId().equals(id)) {
				return c;
			}
		}
		return null;
	}

	/**
	 * Create new year in dummy database. Updates the id and insert new
	 * year in list.
	 * 
	 * @param year
	 *            Year object
	 * @return year object with updated id
	 */
	public Year create(Year year) {
		year.setId(System.currentTimeMillis());
		years.add(year);
		return year;
	}

	/**
	 * Delete the year object from dummy database. If year not found for
	 * given id, returns null.
	 * 
	 * @param id
	 *            the year id
	 * @return id of deleted year object
	 */
	public Long delete(Long id) {

		for (Year c : years) {
			if (c.getId().equals(id)) {
				years.remove(c);
				return id;
			}
		}

		return null;
	}

	/**
	 * Update the year object for given id in dummy database. If year
	 * not exists, returns null
	 * 
	 * @param id
	 * @param year
	 * @return year object with id
	 */
	public Year update(Long id, Year year) {

		for (Year c : years) {
			if (c.getId().equals(id)) {
				year.setId(c.getId());
				years.remove(c);
				years.add(year);
				return year;
			}
		}

		return null;
	}

}
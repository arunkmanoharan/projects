package com.findyourcar.spring.model;

public class Cylinders {

	private Long id;
	private String cylinders;

	public Cylinders(long id, String cylinders) {
		this.id = id;
		this.cylinders = cylinders;
	}

	public Cylinders() {
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getCylinders() {
		return cylinders;
	}

	public void setCylinders(String cylinders) {
		this.cylinders = cylinders;
	}
}
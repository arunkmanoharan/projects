package com.findyourcar.spring.dao;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import com.findyourcar.spring.model.Model;

@Component
public class ModelDAO {

	// Dummy database. Initialize with some dummy values.
	private static List<Model> models;
	{
		models = new ArrayList();
		models.add(new Model(1, "Model1"));
		models.add(new Model(2, "Model2"));
		models.add(new Model(3, "Model3"));
		models.add(new Model(4, "Model4"));
	}

	/**
	 * Returns list of models from dummy database.
	 * 
	 * @return list of models
	 */
	public List list() {
		return models;
	}

	/**
	 * Return model object for given id from dummy database. If model is
	 * not found for id, returns null.
	 * 
	 * @param id
	 *            model id
	 * @return model object for given id
	 */
	public Model get(Long id) {

		for (Model c : models) {
			if (c.getId().equals(id)) {
				return c;
			}
		}
		return null;
	}

	/**
	 * Create new model in dummy database. Updates the id and insert new
	 * model in list.
	 * 
	 * @param model
	 *            Model object
	 * @return model object with updated id
	 */
	public Model create(Model model) {
		model.setId(System.currentTimeMillis());
		models.add(model);
		return model;
	}

	/**
	 * Delete the model object from dummy database. If model not found for
	 * given id, returns null.
	 * 
	 * @param id
	 *            the model id
	 * @return id of deleted model object
	 */
	public Long delete(Long id) {

		for (Model c : models) {
			if (c.getId().equals(id)) {
				models.remove(c);
				return id;
			}
		}

		return null;
	}

	/**
	 * Update the model object for given id in dummy database. If model
	 * not exists, returns null
	 * 
	 * @param id
	 * @param model
	 * @return model object with id
	 */
	public Model update(Long id, Model model) {

		for (Model c : models) {
			if (c.getId().equals(id)) {
				model.setId(c.getId());
				models.remove(c);
				models.add(model);
				return model;
			}
		}

		return null;
	}

}
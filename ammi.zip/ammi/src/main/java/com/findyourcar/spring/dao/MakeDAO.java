package com.findyourcar.spring.dao;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import com.findyourcar.spring.model.Make;

@Component
public class MakeDAO {

	// Dummy database. Initialize with some dummy values.
	private static List<Make> makes;
	{
		makes = new ArrayList();
		makes.add(new Make(1, "Make1"));
		makes.add(new Make(2, "Make2"));
		makes.add(new Make(3, "Make3"));
		makes.add(new Make(4, "Make4"));
	}

	/**
	 * Returns list of makes from dummy database.
	 * 
	 * @return list of makes
	 */
	public List list() {
		return makes;
	}

	/**
	 * Return make object for given id from dummy database. If make is
	 * not found for id, returns null.
	 * 
	 * @param id
	 *            make id
	 * @return make object for given id
	 */
	public Make get(Long id) {

		for (Make c : makes) {
			if (c.getId().equals(id)) {
				return c;
			}
		}
		return null;
	}

	/**
	 * Create new make in dummy database. Updates the id and insert new
	 * make in list.
	 * 
	 * @param make
	 *            Make object
	 * @return make object with updated id
	 */
	public Make create(Make make) {
		make.setId(System.currentTimeMillis());
		makes.add(make);
		return make;
	}

	/**
	 * Delete the make object from dummy database. If make not found for
	 * given id, returns null.
	 * 
	 * @param id
	 *            the make id
	 * @return id of deleted make object
	 */
	public Long delete(Long id) {

		for (Make c : makes) {
			if (c.getId().equals(id)) {
				makes.remove(c);
				return id;
			}
		}

		return null;
	}

	/**
	 * Update the make object for given id in dummy database. If make
	 * not exists, returns null
	 * 
	 * @param id
	 * @param make
	 * @return make object with id
	 */
	public Make update(Long id, Make make) {

		for (Make c : makes) {
			if (c.getId().equals(id)) {
				make.setId(c.getId());
				makes.remove(c);
				makes.add(make);
				return make;
			}
		}

		return null;
	}

}
package com.findyourcar.spring.dao;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import com.findyourcar.spring.model.State;

@Component
public class StateDAO {

	// Dummy database. Initialize with some dummy values.
	private static List<State> states;
	{
		states = new ArrayList();
		states.add(new State(1, "State1"));
		states.add(new State(2, "State2"));
		states.add(new State(3, "State3"));
		states.add(new State(4, "State4"));
	}

	/**
	 * Returns list of states from dummy database.
	 * 
	 * @return list of states
	 */
	public List list() {
		return states;
	}

	/**
	 * Return state object for given id from dummy database. If state is
	 * not found for id, returns null.
	 * 
	 * @param id
	 *            state id
	 * @return state object for given id
	 */
	public State get(Long id) {

		for (State c : states) {
			if (c.getId().equals(id)) {
				return c;
			}
		}
		return null;
	}

	/**
	 * Create new state in dummy database. Updates the id and insert new
	 * state in list.
	 * 
	 * @param state
	 *            State object
	 * @return state object with updated id
	 */
	public State create(State state) {
		state.setId(System.currentTimeMillis());
		states.add(state);
		return state;
	}

	/**
	 * Delete the state object from dummy database. If state not found for
	 * given id, returns null.
	 * 
	 * @param id
	 *            the state id
	 * @return id of deleted state object
	 */
	public Long delete(Long id) {

		for (State c : states) {
			if (c.getId().equals(id)) {
				states.remove(c);
				return id;
			}
		}

		return null;
	}

	/**
	 * Update the state object for given id in dummy database. If state
	 * not exists, returns null
	 * 
	 * @param id
	 * @param state
	 * @return state object with id
	 */
	public State update(Long id, State state) {

		for (State c : states) {
			if (c.getId().equals(id)) {
				state.setId(c.getId());
				states.remove(c);
				states.add(state);
				return state;
			}
		}

		return null;
	}

}
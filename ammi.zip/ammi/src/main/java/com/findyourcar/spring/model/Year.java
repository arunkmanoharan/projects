package com.findyourcar.spring.model;

public class Year {

	private Long id;
	private String year;

	public Year(long id, String year) {
		this.id = id;
		this.year = year;
	}

	public Year() {
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getYear() {
		return year;
	}

	public void setYear(String year) {
		this.year = year;
	}
}
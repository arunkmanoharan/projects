package com.findyourcar.spring.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.findyourcar.spring.dao.StateDAO;
import com.findyourcar.spring.model.State;

@RestController
public class StateRestController {

	
	@Autowired
	private StateDAO stateDAO;

	
	@GetMapping("/states")
	public List getStates() {
		return stateDAO.list();
	}

	@GetMapping("/states/{id}")
	public ResponseEntity getState(@PathVariable("id") Long id) {

		State state = stateDAO.get(id);
		if (state == null) {
			return new ResponseEntity("No State found for ID " + id, HttpStatus.NOT_FOUND);
		}

		return new ResponseEntity(state, HttpStatus.OK);
	}

	@PostMapping(value = "/states")
	public ResponseEntity createState(@RequestBody State state) {

		stateDAO.create(state);

		return new ResponseEntity(state, HttpStatus.OK);
	}

	@DeleteMapping("/states/{id}")
	public ResponseEntity deleteState(@PathVariable Long id) {

		if (null == stateDAO.delete(id)) {
			return new ResponseEntity("No State found for ID " + id, HttpStatus.NOT_FOUND);
		}

		return new ResponseEntity(id, HttpStatus.OK);

	}

	@PutMapping("/states/{id}")
	public ResponseEntity updateState(@PathVariable Long id, @RequestBody State state) {

		state = stateDAO.update(id, state);

		if (null == state) {
			return new ResponseEntity("No State found for ID " + id, HttpStatus.NOT_FOUND);
		}

		return new ResponseEntity(state, HttpStatus.OK);
	}

}
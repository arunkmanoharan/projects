package com.findyourcar.spring.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.CrossOrigin;

import com.findyourcar.spring.dao.BodyTypeDAO;
import com.findyourcar.spring.model.BodyType;

@RestController
public class BodyTypeRestController {

	
	@Autowired
	private BodyTypeDAO bodytypeDAO;

	@GetMapping("/bodytypes")
	public List getBodyTypes() {
		return bodytypeDAO.list();
	}

	@GetMapping("/bodytypes/{id}")
	public ResponseEntity getBodyType(@PathVariable("id") Long id) {

		BodyType bodytype = bodytypeDAO.get(id);
		if (bodytype == null) {
			return new ResponseEntity("No BodyType found for ID " + id, HttpStatus.NOT_FOUND);
		}

		return new ResponseEntity(bodytype, HttpStatus.OK);
	}

	@PostMapping(value = "/bodytypes")
	public ResponseEntity createBodyType(@RequestBody BodyType bodytype) {

		bodytypeDAO.create(bodytype);

		return new ResponseEntity(bodytype, HttpStatus.OK);
	}

	@DeleteMapping("/bodytypes/{id}")
	public ResponseEntity deleteBodyType(@PathVariable Long id) {

		if (null == bodytypeDAO.delete(id)) {
			return new ResponseEntity("No BodyType found for ID " + id, HttpStatus.NOT_FOUND);
		}

		return new ResponseEntity(id, HttpStatus.OK);

	}

	@PutMapping("/bodytypes/{id}")
	public ResponseEntity updateBodyType(@PathVariable Long id, @RequestBody BodyType bodytype) {

		bodytype = bodytypeDAO.update(id, bodytype);

		if (null == bodytype) {
			return new ResponseEntity("No BodyType found for ID " + id, HttpStatus.NOT_FOUND);
		}

		return new ResponseEntity(bodytype, HttpStatus.OK);
	}

}
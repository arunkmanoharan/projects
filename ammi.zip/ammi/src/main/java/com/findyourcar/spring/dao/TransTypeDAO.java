package com.findyourcar.spring.dao;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import com.findyourcar.spring.model.TransType;

@Component
public class TransTypeDAO {

	// Dummy database. Initialize with some dummy values.
	private static List<TransType> transTypes;
	{
		transTypes = new ArrayList();
		transTypes.add(new TransType(1, "TransType1"));
		transTypes.add(new TransType(2, "TransType2"));
		transTypes.add(new TransType(3, "TransType3"));
		transTypes.add(new TransType(4, "TransType4"));
	}

	/**
	 * Returns list of transTypes from dummy database.
	 * 
	 * @return list of transTypes
	 */
	public List list() {
		return transTypes;
	}

	/**
	 * Return transType object for given id from dummy database. If transType is
	 * not found for id, returns null.
	 * 
	 * @param id
	 *            transType id
	 * @return transType object for given id
	 */
	public TransType get(Long id) {

		for (TransType c : transTypes) {
			if (c.getId().equals(id)) {
				return c;
			}
		}
		return null;
	}

	/**
	 * Create new transType in dummy database. Updates the id and insert new
	 * transType in list.
	 * 
	 * @param transType
	 *            TransType object
	 * @return transType object with updated id
	 */
	public TransType create(TransType transType) {
		transType.setId(System.currentTimeMillis());
		transTypes.add(transType);
		return transType;
	}

	/**
	 * Delete the transType object from dummy database. If transType not found for
	 * given id, returns null.
	 * 
	 * @param id
	 *            the transType id
	 * @return id of deleted transType object
	 */
	public Long delete(Long id) {

		for (TransType c : transTypes) {
			if (c.getId().equals(id)) {
				transTypes.remove(c);
				return id;
			}
		}

		return null;
	}

	/**
	 * Update the transType object for given id in dummy database. If transType
	 * not exists, returns null
	 * 
	 * @param id
	 * @param transType
	 * @return transType object with id
	 */
	public TransType update(Long id, TransType transType) {

		for (TransType c : transTypes) {
			if (c.getId().equals(id)) {
				transType.setId(c.getId());
				transTypes.remove(c);
				transTypes.add(transType);
				return transType;
			}
		}

		return null;
	}

}
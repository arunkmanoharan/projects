package com.findyourcar.spring.model;

public class TransType {

	private Long id;
	private String transType;

	public TransType(long id, String transType) {
		this.id = id;
		this.transType = transType;
	}

	public TransType() {
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getTransType() {
		return transType;
	}

	public void setTransType(String transType) {
		this.transType = transType;
	}
}
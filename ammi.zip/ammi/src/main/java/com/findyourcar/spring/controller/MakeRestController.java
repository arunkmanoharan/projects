package com.findyourcar.spring.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.findyourcar.spring.dao.MakeDAO;
import com.findyourcar.spring.model.Make;

@RestController
public class MakeRestController {

	
	@Autowired
	private MakeDAO makeDAO;

	
	@GetMapping("/makes")
	public List getMakes() {
		return makeDAO.list();
	}

	@GetMapping("/makes/{id}")
	public ResponseEntity getMake(@PathVariable("id") Long id) {

		Make make = makeDAO.get(id);
		if (make == null) {
			return new ResponseEntity("No Make found for ID " + id, HttpStatus.NOT_FOUND);
		}

		return new ResponseEntity(make, HttpStatus.OK);
	}

	@PostMapping(value = "/makes")
	public ResponseEntity createMake(@RequestBody Make make) {

		makeDAO.create(make);

		return new ResponseEntity(make, HttpStatus.OK);
	}

	@DeleteMapping("/makes/{id}")
	public ResponseEntity deleteMake(@PathVariable Long id) {

		if (null == makeDAO.delete(id)) {
			return new ResponseEntity("No Make found for ID " + id, HttpStatus.NOT_FOUND);
		}

		return new ResponseEntity(id, HttpStatus.OK);

	}

	@PutMapping("/makes/{id}")
	public ResponseEntity updateMake(@PathVariable Long id, @RequestBody Make make) {

		make = makeDAO.update(id, make);

		if (null == make) {
			return new ResponseEntity("No Make found for ID " + id, HttpStatus.NOT_FOUND);
		}

		return new ResponseEntity(make, HttpStatus.OK);
	}

}
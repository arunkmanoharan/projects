package com.findyourcar.spring.model;

public class BodyType {

	private Long id;
	private String bodyType;

	public BodyType(long id, String bodyType) {
		this.id = id;
		this.bodyType = bodyType;
	}

	public BodyType() {
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getBodyType() {
		return bodyType;
	}

	public void setBodyType(String bodyType) {
		this.bodyType = bodyType;
	}
}
package com.findyourcar.spring.dao;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import com.findyourcar.spring.model.Cylinders;

@Component
public class CylindersDAO {

	// Dummy database. Initialize with some dummy values.
	private static List<Cylinders> cylinders;
	{
		cylinders = new ArrayList();
		cylinders.add(new Cylinders(1, "Cylinder1"));
		cylinders.add(new Cylinders(2, "Cylinder1"));
		cylinders.add(new Cylinders(3, "Cylinder1"));
		cylinders.add(new Cylinders(4, "Cylinder1"));
	}

	/**
	 * Returns list of cylinders from dummy database.
	 * 
	 * @return list of cylinders
	 */
	public List list() {
		return cylinders;
	}

	/**
	 * Return cylinder object for given id from dummy database. If cylinder is
	 * not found for id, returns null.
	 * 
	 * @param id
	 *            cylinder id
	 * @return cylinder object for given id
	 */
	public Cylinders get(Long id) {

		for (Cylinders c : cylinders) {
			if (c.getId().equals(id)) {
				return c;
			}
		}
		return null;
	}

	/**
	 * Create new cylinder in dummy database. Updates the id and insert new
	 * cylinder in list.
	 * 
	 * @param cylinder
	 *            Cylinders object
	 * @return cylinder object with updated id
	 */
	public Cylinders create(Cylinders cylinder) {
		cylinder.setId(System.currentTimeMillis());
		cylinders.add(cylinder);
		return cylinder;
	}

	/**
	 * Delete the cylinder object from dummy database. If cylinder not found for
	 * given id, returns null.
	 * 
	 * @param id
	 *            the cylinder id
	 * @return id of deleted cylinder object
	 */
	public Long delete(Long id) {

		for (Cylinders c : cylinders) {
			if (c.getId().equals(id)) {
				cylinders.remove(c);
				return id;
			}
		}

		return null;
	}

	/**
	 * Update the cylinder object for given id in dummy database. If cylinder
	 * not exists, returns null
	 * 
	 * @param id
	 * @param cylinder
	 * @return cylinder object with id
	 */
	public Cylinders update(Long id, Cylinders cylinder) {

		for (Cylinders c : cylinders) {
			if (c.getId().equals(id)) {
				cylinder.setId(c.getId());
				cylinders.remove(c);
				cylinders.add(cylinder);
				return cylinder;
			}
		}

		return null;
	}

}